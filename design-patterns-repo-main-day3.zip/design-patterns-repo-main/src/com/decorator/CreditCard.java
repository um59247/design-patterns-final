package com.decorator;

public abstract class CreditCard {
	public abstract void features(); 
}
