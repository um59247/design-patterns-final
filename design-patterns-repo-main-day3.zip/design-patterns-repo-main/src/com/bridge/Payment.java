package com.bridge;

public interface Payment {
	void limit();
}
