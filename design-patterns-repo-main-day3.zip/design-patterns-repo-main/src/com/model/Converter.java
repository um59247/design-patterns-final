package com.model;

public interface Converter {
	public String convert();
}
