package com.model;

public abstract  class Account {
	public abstract String getAccountNumber();
	public abstract double getRateOfInterest();
}
