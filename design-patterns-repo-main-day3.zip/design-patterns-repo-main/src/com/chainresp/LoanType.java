package com.chainresp;

public enum LoanType {
PERSONAL, HOME
}
