package com.solidprinciples;

public class Test {

}

interface Vehicle{
	public void computeMileage();
	
}
interface CarTemplate extends Vehicle{
	public void getVariant();
}
class Car implements CarTemplate{
	@Override
	public void computeMileage() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void getVariant() {
		// TODO Auto-generated method stub
		
	}
}
 class Bike implements Vehicle{
	@Override
	public void computeMileage() {
		// TODO Auto-generated method stub
		
	}
}
 


class Handler{
	
}

class UPI extends Handler{}
class NEFT extends Handler{ }

class Transaction{
	Handler handler; 
	
	
}








