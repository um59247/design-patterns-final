package com.exception;

public interface Transaction{
	void process(Customer c, double amount);
}
