package com.exception;

public class DepositService implements Deposit{
	
	@Override
	public void process(Customer c, double amount) {
		c.setBalace(c.getBalace()+amount);
		
	}
}
