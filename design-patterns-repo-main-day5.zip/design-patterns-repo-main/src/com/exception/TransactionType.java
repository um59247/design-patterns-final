package com.exception;

public enum TransactionType {
DEPOSIT,WITHDRAWAL
}
