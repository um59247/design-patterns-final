package com.exception;

public class ExceptionController {
	public static void main(String[] args) {
		Transaction transaction = new WithdrawalService();
		Validator validator = new ValidationService();
		
		Customer c1 = new Customer("harry potter", 45000);
		
		/* Do withdrawal*/
		try {
			double amount = -47000;
			validator.validate(TransactionType.WITHDRAWAL, c1, amount);
			transaction.process(c1, amount);
			System.out.println(c1);
		} catch (InsufficientFundsException | OverTheLimitException | InvalidAmountException e) {
			 System.out.println(e.getMessage());
		}
		finally {
			validator = null;
			transaction = null; 
			c1=null; 
			System.out.println("Thank you");
		}

		
	}
}
/* 
 * Customer c1 = new Customer("harry potter", 45000);
 * double amount = -47000;
 * try{
 *  validator.validate(TransactionType.WITHDRAWAL, c1, amount);
 * }
 * catch(InvalidAmountException e){
 * 	assertEquals("Amount cannot be less than Zero", e.getMessage); 
 * }
 * */












