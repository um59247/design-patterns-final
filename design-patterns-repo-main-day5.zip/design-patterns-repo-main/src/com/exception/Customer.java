package com.exception;

public class Customer {
	private String name;
	private double balace;
	public Customer(String name, double balace) {
		super();
		this.name = name;
		this.balace = balace;
	}
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", balace=" + balace + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getBalace() {
		return balace;
	}
	public void setBalace(double balace) {
		this.balace = balace;
	} 
	
	
}
