package com.exception;

public class WithdrawalService implements Withdrawal{

	@Override
	public void process(Customer c, double amount) {
 		 
		c.setBalace(c.getBalace() - amount); 
	}
}
