package com.exception;

public interface Deposit extends Transaction{
	
 }
