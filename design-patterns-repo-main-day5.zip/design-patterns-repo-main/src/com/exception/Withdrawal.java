package com.exception;

public interface Withdrawal extends Transaction{
	
	 
}
/* 
 * 1. if the amount>balance : InsufficientFundsException 
 * 2. amount <0, InvalidAmountException
 * 3. amount>limit, OverTheLimitException
 */

