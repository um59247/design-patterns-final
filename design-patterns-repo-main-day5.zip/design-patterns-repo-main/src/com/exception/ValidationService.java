package com.exception;

public class ValidationService implements Validator{
	
	@Override
	public boolean validate( TransactionType type, Customer c, double amount)
			throws InsufficientFundsException, OverTheLimitException, InvalidAmountException {
		
		switch(type.toString()) {
		case "DEPOSIT":
			 
			 return true;
			 
		case "WITHDRAWAL":
			if(amount < 0)
				throw new InvalidAmountException("Amount cannot be less than Zero");
			if(amount > Validator.limit)
				throw new OverTheLimitException("Amount is greater than limit");
			if(amount > c.getBalace())
				throw new InsufficientFundsException("Insufficient balance");
			
			return true;
		 default: 
			 return true; 
		}
		
	}
}
