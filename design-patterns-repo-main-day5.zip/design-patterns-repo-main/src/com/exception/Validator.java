package com.exception;

public interface Validator {
	double limit = 50000; //final and static
	public boolean validate(TransactionType type, Customer c, double amount) 
			throws InsufficientFundsException,
		    OverTheLimitException,
		    InvalidAmountException;
}
