package com.facade;

public interface CreditCard {
	void getLimit();
	void charges();
}
