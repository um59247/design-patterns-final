package com.visitor;

public interface Visitor {

	public double getCharge();
}
