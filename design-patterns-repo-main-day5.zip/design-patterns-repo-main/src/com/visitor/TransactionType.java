package com.visitor;

public enum TransactionType {
UPI,NEFT,RTGS
}
