package com.visitor;

public interface Visitable {
	public void accept();
}
